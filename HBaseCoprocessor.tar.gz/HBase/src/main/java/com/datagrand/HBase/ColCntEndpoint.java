package com.datagrand.HBase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.Coprocessor;
import org.apache.hadoop.hbase.CoprocessorEnvironment;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.coprocessor.CoprocessorException;
import org.apache.hadoop.hbase.coprocessor.CoprocessorService;
import org.apache.hadoop.hbase.coprocessor.RegionCoprocessor;
import org.apache.hadoop.hbase.coprocessor.RegionCoprocessorEnvironment;
import org.apache.hadoop.hbase.filter.*;
import org.apache.hadoop.hbase.shaded.protobuf.ResponseConverter;
import org.apache.hadoop.hbase.regionserver.InternalScanner;
import org.apache.hadoop.hbase.util.Bytes;
import com.google.protobuf.RpcCallback;
import com.google.protobuf.RpcController;
import com.google.protobuf.Service;

////com.datagrand.HBase.ColCntEndpoint

public class ColCntEndpoint extends Cnt.CntService implements
        RegionCoprocessor {
    private RegionCoprocessorEnvironment env;
    private static final Log LOG = LogFactory.getLog(ColCntEndpoint.class);

    @Override
    public Iterable<Service> getServices() {
        return Collections.singleton(this);
    }

//    @Override
//    public Service getService() {
//        return this;
//    }

    @Override
    public void start(CoprocessorEnvironment env) throws IOException {
        if (env instanceof RegionCoprocessorEnvironment) {
            this.env = (RegionCoprocessorEnvironment) env;
            LOG.info("=====================this.env = (RegionCoprocessorEnvironment)env;========================");
        } else {
            throw new CoprocessorException("Must be loaded on a table region!");
        }
    }

    @Override
    public void stop(CoprocessorEnvironment env) throws IOException {
        // do nothing
    }

    @Override
    public void getCnt(RpcController controller, Cnt.CntRequest request, RpcCallback<Cnt.CntResponse> done) {
        Cnt.CntResponse.Builder respBuilder = Cnt.CntResponse.newBuilder();
        InternalScanner scanner = null;
        long sum = 0L;
        try {
            Scan scan = new Scan();
            scan.addFamily(Bytes.toBytes(request.getFamily()));
            scan.addColumn(Bytes.toBytes(request.getFamily()), Bytes.toBytes(request.getColumn()));
            LOG.info("Cnt: cf, col :==================>" + request.getFamily()+","+request.getColumn());
            LOG.info("getRegionInfo()=================>" + env.getRegionInfo());

            scanner = env.getRegion().getScanner(scan);
            List<Cell> results = new ArrayList<>();
            boolean hasMore;
            do {
                hasMore = scanner.next(results);
                if (results.size() > 0) {
                    sum++;
                }
                results.clear();
            } while (hasMore);

            respBuilder.setCnt(sum);
        } catch (IOException ioe) {
            ResponseConverter.setControllerException(controller, ioe);
        } finally {
            if (scanner != null) {
                try {
                    scanner.close();
                } catch (IOException ignored) {}
            }
        }
        done.run(respBuilder.build());
    }
}
